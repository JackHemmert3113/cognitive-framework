# Requirements Project Structure

This repository uses a standardized, TPM-aligned markdown structure to manage software requirements, test stories, and feature development.

---

## 📂 Folder Structure

```
docs/
└── requirements/
    ├── vision/
    │   └── TESTS.vision.md
    ├── business-value/
    │   └── TESTS.business-value.md
    ├── epics/
    │   └── TESTS.03.md
    ├── features/
    │   └── TESTS.03.03.md
    ├── stories/
    │   └── TESTS.03.03.01.md
    ├── README.md
    ├── TESTS.index.md
    ├── TESTS.03_index.md
    ├── REQUIREMENTS_PROMPT_SCHEMA.md
```

---

## ✅ Requirements Format

Each story includes:
- 🧑‍💻 Human Format
- ✅ Acceptance Criteria
- 🤖 AI Format
- 📋 Tasks
- 🔗 Related links

Each feature includes:
- 🧩 Capability
- 💡 Benefit
- ✅ Validation
- 🔗 Related links

Each epic includes:
- ❗ Problem
- 🎯 Goal
- 📦 Scope
- 🔗 Related links

---

## 🧠 Prompting Examples

- “Trace TESTS.03.03.01 back to business value”
- “Show me the tasks to implement TESTS.03.01.01”
- “Propose a new story for TESTS.03.05”

For more detail, see [`REQUIREMENTS_PROMPT_SCHEMA.md`](./REQUIREMENTS_PROMPT_SCHEMA.md)
