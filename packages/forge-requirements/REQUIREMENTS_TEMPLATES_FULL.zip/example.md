# TESTS.03.03.01 — AI-Assisted Test Failure Analysis

---

## 🧑‍💻 Human Format

**As** a test automation engineer,  
**I want** the system to automatically summarize the root cause of test failures,  
**So that** I can understand and resolve issues faster.

### ✅ Acceptance Criteria
- Input: Test output logs, stack trace, optional screenshot
- Output: Markdown summary explaining root cause
- Includes: Confidence score, suggested fix, and failed step
- Appears: In PR comment or test dashboard

---

## 🤖 AI Format

**Objective**:  
Analyze logs and traces from failed tests and generate a root cause summary using LLMs.

**Requirements**:
- Use prompt template: “Summarize why this test failed”
- Input: JSON with fields: `testId`, `logs[]`, `stack[]`, `diffs[]`
- Output: Markdown blob with title, failure type, and summary

**Validation**:
- PR contains a visible failure summary
- Summary matches test failure cause with >80% confidence

---

## 📋 Tasks

- [ ] Define prompt template in `ai-test-orchestrator.js`
- [ ] Implement log parser for failed runs
- [ ] Send structured test payloads to LLM endpoint
- [ ] Store generated summaries in `test-results/failures/`
- [ ] Render result in GitHub PR comment

---

## 🔗 Related:
- Feature: [TESTS.03.03](../features/TESTS.03.03.md)
