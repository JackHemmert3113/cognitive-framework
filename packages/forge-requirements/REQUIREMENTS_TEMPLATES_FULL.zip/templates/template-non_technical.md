# Non-Technical Contributor Requirements Template

## Requirement Title

**Unique ID:**  
(Use the next available ID, e.g., FEAT-002)

**Summary:**  
(Describe the need or user story in plain language.)

**Why is this needed?**  
(Explain the benefit or problem it will solve.)

**What does success look like?**  
(Describe what "done" means in your own words.)

**Related Ideas or Feedback:**  
- (Paste any relevant emails, meeting notes, or customer feedback.)

**Contributor:**  
(Name and contact info)



---

## 🧭 TPM-Aligned Structure Guidelines

This project follows a unified, cross-linked markdown standard for all requirements:

### 📐 Requirement Layers
- 🔭 Vision → ❗ Epics → 🧩 Features → 🧪 Stories

### 📄 Story Format
Each story must include:
- 🧑‍💻 Human Format (user need and intent)
- ✅ Acceptance Criteria (clear pass/fail success criteria)
- 🤖 AI Format (how to execute)
- 📋 Tasks (1–2 point developer tasks)
- 🔗 Related: link to its feature

### 🧩 Feature Format
- 🧩 Capability
- 💡 Benefit
- ✅ Validation
- 🔗 Related: links to epic and child stories

### 🧱 Epic Format
- ❗ Problem
- 🎯 Goal
- 📦 Scope
- 🔗 Related: links to features and vision

### 🔭 Vision Format
“Our vision is to [what] by [how] so that [who benefits]”

---

## 🧠 Pro Tips for Your Role


- You can focus on Human Format and Acceptance Criteria
- Don’t worry about AI Format—leave that to engineering and agents
- Ask: “Can someone validate this without seeing the code?”