# Reviewer / QA Requirements Template

## Requirement Title

**Unique ID:**  
(Reference the requirement or story ID.)

**Test Cases / Scenarios:**  
- (List each test case required to verify the acceptance criteria.)

**Acceptance Criteria Reference:**  
- (Restate or link to the acceptance criteria.)

**Steps to Reproduce / Validate:**  
1. (Step-by-step validation process.)

**Expected Results:**  
- (Describe expected outcomes for each scenario.)

**Actual Results:**  
- (To be filled during testing.)

**Status:**  
- [ ] Pass
- [ ] Fail
- [ ] Blocked

**Reviewer:**  
(Name or GitHub handle)



---

## 🧭 TPM-Aligned Structure Guidelines

This project follows a unified, cross-linked markdown standard for all requirements:

### 📐 Requirement Layers
- 🔭 Vision → ❗ Epics → 🧩 Features → 🧪 Stories

### 📄 Story Format
Each story must include:
- 🧑‍💻 Human Format (user need and intent)
- ✅ Acceptance Criteria (clear pass/fail success criteria)
- 🤖 AI Format (how to execute)
- 📋 Tasks (1–2 point developer tasks)
- 🔗 Related: link to its feature

### 🧩 Feature Format
- 🧩 Capability
- 💡 Benefit
- ✅ Validation
- 🔗 Related: links to epic and child stories

### 🧱 Epic Format
- ❗ Problem
- 🎯 Goal
- 📦 Scope
- 🔗 Related: links to features and vision

### 🔭 Vision Format
“Our vision is to [what] by [how] so that [who benefits]”

---

## 🧠 Pro Tips for Your Role


- You are the owner of the Acceptance Criteria
- Use ACs to design tests and confirm completion
- Suggest changes if ACs are ambiguous or incomplete