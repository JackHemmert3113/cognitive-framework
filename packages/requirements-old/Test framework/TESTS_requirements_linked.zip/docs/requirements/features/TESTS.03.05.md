# TESTS.03.05 — Orchestrator CLI

## 🧩 Capability
Run individual or grouped test scenarios by ID via terminal

## 💡 Benefit
Enables faster local debugging and automation hooks

## ✅ Validation
CLI command executes a scenario and prints structured logs


## 🔗 Related:
- Epic: [TESTS.03](../epics/TESTS.03.md)
- Story: [TESTS.03.05.01](../stories/TESTS.03.05.01.md)