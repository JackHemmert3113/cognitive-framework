# TESTS.02.01 — Reusable Test Data Generators

## 🧩 Capability
Generate realistic workouts, meals, and user profiles for test environments

## 💡 Benefit
Reduces boilerplate and ensures consistency across packages

## ✅ Validation
All test suites can generate valid data via a shared utility and override individual fields


## 🔗 Related:
- Epic: [TESTS.02](../epics/TESTS.02.md)
- Story: [TESTS.02.01.01](../stories/TESTS.02.01.01.md)