# TESTS.03.03 — AI-Assisted Failure Diagnosis

## 🧩 Capability
Summarize root cause of test failures using LLMs

## 💡 Benefit
Speeds up debugging by offering human-readable summaries and suggestions

## ✅ Validation
Markdown summary appears on test failure with confidence score


## 🔗 Related:
- Epic: [TESTS.03](../epics/TESTS.03.md)
- Story: [TESTS.03.03.01](../stories/TESTS.03.03.01.md)