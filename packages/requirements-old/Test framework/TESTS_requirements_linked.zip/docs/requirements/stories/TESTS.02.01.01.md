# TESTS.02.01.01 – Auto-generate test data for common scenarios

---

## 🧑‍💻 Human Format (Product Intent)

**As** a backend developer,  
**I want** generate workout and meal objects for validation tests,  
**So that** I can write unit and integration tests with less setup code.

### ✅ Acceptance Criteria
- Entities covered:
- Workout
- Meal
- AC is verified by automated test runs in CI
- Any regression causes a visible failure with actionable logs

---

## 🤖 AI Format (Execution Structure)

**Objective:**  
Implement support for these entities:
- Workout
- Meal

**Requirements:**
- Ensure modular and reusable implementation
- Align input/output with agent and human-facing formats
- Integrate with CI and dev workflows
- Provide logs or errors in structured output

**Validation:**
- AI agents can read and validate structure
- Engineers confirm story via tests and CLI tools

---

## 📋 Tasks

- [ ] Create `generateWorkout()` and `generateMeal()` helpers
- [ ] Export from `wellness-test-utils.js`
- [ ] Support overrides for each field to test edge cases
- [ ] Include type guards to validate returned structures


## 🔗 Related:
- Feature: [TESTS.02.01](../features/TESTS.02.01.md)
