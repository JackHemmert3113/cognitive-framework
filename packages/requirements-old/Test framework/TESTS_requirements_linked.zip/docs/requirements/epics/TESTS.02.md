# TESTS.02 — Test Data Generation and Validation Utilities

## ❗ Problem
Test data is tedious to write and inconsistent across packages.

## 🎯 Goal
Provide reusable, override-friendly generators and validators for workouts, meals, profiles, and health metrics.

## 📦 Scope
- Wellness test utility library
- Fuzzed data support
- Validation contracts
- Edge case and override systems


## 🔗 Related:
- Vision: [TESTS.vision.md](../vision/TESTS.vision.md)
- Feature: [TESTS.02.01](../features/TESTS.02.01.md)